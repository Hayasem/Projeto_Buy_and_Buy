package com.example.tela_login_projetointegrador;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class TelaPerfilUsuario extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_perfil_usuario);
    }
}